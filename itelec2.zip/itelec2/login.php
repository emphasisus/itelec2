<?php
require_once "includes/config.inc.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 400px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .container h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
        margin-bottom: 20px;
        }

        .form-group select,
        .form-group textarea {
            width: 100%;
            max-width: 300px; /* Adjust the value as needed */
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input[type="text"],
        .form-group input[type="password"] {
            width: 100%;
            max-width: 400px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box;
        }

        .form-group .error {
            color: red;
            margin-top: 5px;
        }

        .form-group .input-error {
            border-color: red;
        }

        .form-group .input-error:focus {
            outline-color: red;
        }

        .form-group button {
            padding: 10px 20px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Login</h1>

        <a href="register.php">Register</a> |
        <a href="contact.php">Contact Us</a> |
        <a href="login.php">Login</a><br /><br />

        <form action="includes/login.inc.php" method="get">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" name="username" id="username" placeholder="Enter Username..." <?= isset($_SESSION['errors']['username']) ? 'class="input-error"' : '' ?> value="<?= isset($_SESSION['inputs']['username']) ? $_SESSION['inputs']['username'] : '' ?>" required>
                <?= isset($_SESSION['errors']['username']) ? '<div class="error">' . $_SESSION['errors']['username'] . '</div>' : '' ?>
            </div>

            <div class="form-group">
                <label for="pwd">Password</label>
                <input type="password" name="pwd" id="pwd" placeholder="Enter Password..." <?= isset($_SESSION['errors']['pwd']) ? 'class="input-error"' : '' ?> required>
                <?= isset($_SESSION['errors']['pwd']) ? '<div class="error">' . $_SESSION['errors']['pwd'] . '</div>' : '' ?>
            </div>

            <div class="form-group">
                <button type="submit">Log In</button>
            </div>
        </form>
    </div>
</body>

</html>