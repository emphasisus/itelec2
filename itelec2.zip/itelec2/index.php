<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 400px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        .container h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        .container a {
            text-decoration: none;
            color: #333;
            margin-right: 10px;
        }

        .container a:hover {
            text-decoration: underline;
        }

        .search-form {
            display: flex;
            align-items: center;
        }

        .search-form input[type="text"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            width: 100%;
        }

        .search-form button {
            padding: 10px 20px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 3px;
            margin-left: 10px;
            cursor: pointer;
        }

        .search-form button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Search</h1>
        <a href="index.php">Home</a>|
        <a href="comments.php">Comments</a>|
        <a href="contact.php">Contact Us</a>|
        <a href="login.php">Logout</a><br /><br />

        <form class="search-form" action="search.php" method="post">
            <input type="text" name="search" placeholder="Search comments..." />
            <button type="submit">Search</button>
        </form>
    </div>
</body>

</html>