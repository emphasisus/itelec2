<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search = $_POST["search"];

    try {
        require_once "includes/dbc.inc.php";

        $query = "SELECT * FROM comments WHERE comments LIKE :search;";

        $stmt = $pdo->prepare($query);

        $searchTerm = "%$search%";
        $stmt->bindParam(":search", $searchTerm, PDO::PARAM_STR);

        $stmt->execute();

        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $pdo = null;
        $stmt = null;
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../index.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        h3 {
            margin-top: 0;
        }

        .no-results {
            margin: 20px 0;
            padding: 10px;
            background-color: #f1f1f1;
            border-radius: 5px;
        }

        .result {
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }

        .result h2 {
            margin-top: 0;
            font-size: 18px;
        }

        .result p {
            margin-bottom: 0;
        }
    </style>
</head>

<body>
    <div class="container">
    <h1>Search Results:</h1>

    <a href="index.php">Home</a> |
    <a href="comments.php">Comments</a> |
    <a href="contact.php">Contact Us</a> |
    <a href="login.php">Logout</a><br /><br />
        

        <?php if (empty($results)) : ?>
            <div class="no-results">
                <p>There were no results!</p>
            </div>
        <?php else : ?>
            <?php foreach ($results as $row) : ?>
                <div class="result">
                    <h2><?= htmlspecialchars($row['user_id']) ?></h2>
                    <p><?= htmlspecialchars($row['comments']) ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>

</html>