<?php
require_once 'includes/config.inc.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 300px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #007bff;
        }
        label {
            font-weight: bold;
            color: #333;
            position: relative;
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        label .icon {
            margin-right: 10px;
        }
        input[type="text"],
        input[type="password"],
        input[type="date"],
        input[type="file"] {
            width: calc(100% - 30px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        button[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
        .login-link {
            text-align: center;
            margin-top: 15px;
        }
        .login-link a {
            color: #007bff;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>User Registration</h2>

        <form action="includes/register.inc.php" method="post" enctype="multipart/form-data">
            <div>
                <label for="firstname"><i class="fas fa-user icon"></i> First Name</label>
                <input type="text" id="firstname" name="firstname" placeholder="First Name" <?= isset($_SESSION['errors']['firstname']) ? 'style="border: 1px solid red;"' : '' ?> value="<?= isset($_SESSION['firstname']) ? $_SESSION['firstname'] : '' ?>">
                <?= isset($_SESSION['errors']['firstname']) ? $_SESSION['errors']['firstname'] : '' ?>
            </div>
            <div>
                <label for="lastname"><i class="fas fa-user icon"></i> Last Name</label>
                <input type="text" id="lastname" name="lastname" placeholder="Last Name" <?= isset($_SESSION['errors']['lastname']) ? 'style="border: 1px solid red;"' : '' ?> value="<?= isset($_SESSION['lastname']) ? $_SESSION['lastname'] : '' ?>">
                <?= isset($_SESSION['errors']['lastname']) ? $_SESSION['errors']['lastname'] : '' ?>
            </div>
            <div>
                <label for="middlename"><i class="fas fa-user icon"></i> Middle Name</label>
                <input type="text" id="middlename" name="middlename" placeholder="Middle Name" <?= isset($_SESSION['errors']['middlename']) ? 'style="border: 1px solid red;"' : '' ?> value="<?= isset($_SESSION['middlename']) ? $_SESSION['middlename'] : '' ?>">
                <?= isset($_SESSION['errors']['middlename']) ? $_SESSION['errors']['middlename'] : '' ?>
            </div>
            <div>
                <label for="suffix"><i class="fas fa-user icon"></i> Suffix</label>
                <input type="text" id="suffix" name="suffix" placeholder="Suffix" <?= isset($_SESSION['errors']['suffix']) ? 'style="border: 1px solid red;"' : '' ?> value="<?= isset($_SESSION['suffix']) ? $_SESSION['suffix'] : '' ?>">
                <?= isset($_SESSION['errors']['suffix']) ? $_SESSION['errors']['suffix'] : '' ?>
            </div>
            <div>
                <label for="birthday"><i class="fas fa-calendar-alt icon"></i> Birthdate</label>
                <input type="date" id="birthday" name="birthday" <?= isset($_SESSION['errors']['birthday']) ? 'style="border: 1px solid red;"' : '' ?> value="<?= isset($_SESSION['birthday']) ? $_SESSION['birthday'] : '' ?>">
                <?= isset($_SESSION['errors']['birthday']) ? $_SESSION['errors']['birthday'] : '' ?>
            </div>
            <div>
                <label for="address"><i class="fas fa-map-marker-alt icon"></i> Address</label>
                <input type="text" id="addresss" name="addresss" placeholder="Address" <?= isset($_SESSION['errors']['addresss']) ? 'style="border: 1px solid red;"' : '' ?> value="<?= isset($_SESSION['address']) ? $_SESSION['address'] : '' ?>">
                <?= isset($_SESSION['errors']['addresss']) ? $_SESSION['errors']['addresss'] : '' ?>
            </div>
            <div>
                <label for="contactNum"><i class="fas fa-phone icon"></i> Contact Number</label>
                <input type="text" id="contactNum" name="contactNum" placeholder="09432169519" <?= isset($_SESSION['errors']['contactNum']) ? 'style="border: 1px solid red;"' : '' ?> value="<?= isset($_SESSION['contactNum']) ? $_SESSION['contactNum'] : '' ?>">
                <?= isset($_SESSION['errors']['contactNum']) ? $_SESSION['errors']['contactNum'] : '' ?>
            </div>
            <div>
                <label for="email"><i class="fas fa-envelope icon"></i> Email</label>
                <input type="text" id="email" name="email" placeholder="Email" <?= isset($_SESSION['errors']['email']) ? 'style="border: 1px solid red;"' : '' ?>>
                <?= isset($_SESSION['errors']['email']) ? $_SESSION['errors']['email'] : '' ?>
            </div>
            <div>
                <label for="password"><i class="fas fa-lock icon"></i> Password</label>
                <input type="password" id="password" name="password" placeholder="Password" <?= isset($_SESSION['errors']['password']) ? 'style="border: 1px solid red;"' : '' ?>>
                <?= isset($_SESSION['errors']['password']) ? $_SESSION['errors']['password'] : '' ?>
            </div>
            <div>
                <label for="image"><i class="fas fa-image icon"></i> Profile Picture</label>
                <input type="file" id="image" name="image" accept=".jpg, .png, .jpeg" <?= isset($_SESSION['errors']['image']) ? 'style="border: 1px solid red;"' : '' ?>>
                <?= isset($_SESSION['errors']['image']) ? $_SESSION['errors']['image'] : '' ?>
            </div>
            <button type="submit">Signup</button>
            <div class="login-link">
                Already have an account? <a href="login.php">Login here</a>
            </div>
        </form>
    </div>
    <script>
        <?php if (isset($_SESSION['success'])): ?>
            alert("<?php echo $_SESSION['success']; ?>");
            <?php unset($_SESSION['success']); ?>
        <?php endif; ?>
    </script>
</body>
<?php
    unset($_SESSION['errors']);
 ?>
</html>
