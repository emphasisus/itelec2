<?php
require_once 'includes/config.inc.php';

if(isset($_SESSION['email'])) {
    $email = $_SESSION['email'];

    try {
        require_once "includes/dbc.inc.php";

        $query = "SELECT * FROM useracc WHERE email = :email";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $pdo = null;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    header("Location: login.php");
    exit();
}

if(isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f9fafb;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            max-width: 800px;
            background-color: #fff;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            margin: 20px;
        }

        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }

        .user-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .user-details {
            background-color: #f9f9f9;
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .user-details p {
            margin: 10px 0;
            color: #555;
        }

        .user-details img {
            max-width: 100%;
            height: 200px; 
            object-fit: cover;
            border-radius: 10px;
            margin-top: 20px;
        }

        .logout-btn {
            background-color: #f44336;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 15px 30px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: 20px auto;
        }

        .logout-btn:hover {
            background-color: #d32f2f;
        }

        @media(max-width: 768px) {
            .container {
                padding: 20px;
            }

            .user-details {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>User Information</h1>
        <div class="user-info">
            <?php foreach ($users as $user): ?>
                <div class="user-details">
                    <p><strong>Name:</strong> <?= $user['firstname'] ?> <?= $user['lastname'] ?></p>
                    <p><strong>Middle Name:</strong> <?= $user['middlename'] ?></p>
                    <p><strong>Suffix:</strong> <?= $user['suffix'] ?></p>
                    <p><strong>Birthdate:</strong> <?= $user['birthday'] ?></p>
                    <p><strong>Address:</strong> <?= $user['addresss'] ?></p>
                    <p><strong>Contact Number:</strong> <?= $user['conatctNumber'] ?></p>
                    <?php if (!empty($user['img']) && file_exists('profile_pictures/' . $user['img'])): ?>
                        <img src="profile_pictures/<?= $user['img'] ?>" alt="Profile Picture">
                    <?php else: ?>
                        <p>No profile picture available</p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <form action="" method="post">
            <button class="logout-btn" type="submit" name="logout">Logout</button>
        </form>
    </div>
</body>
</html>
