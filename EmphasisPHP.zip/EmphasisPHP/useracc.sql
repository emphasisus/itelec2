-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2024 at 02:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `activitydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `useracc`
--

CREATE TABLE `useracc` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `middlename` varchar(50) DEFAULT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `conatctNumber` varchar(20) DEFAULT NULL,
  `img` varchar(60) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT curtime(),
  `email` varchar(255) NOT NULL,
  `psswd` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `useracc`
--

INSERT INTO `useracc` (`id`, `firstname`, `lastname`, `middlename`, `suffix`, `birthday`, `conatctNumber`, `img`, `created_at`, `email`, `psswd`) VALUES
(5, 'Juluis', 'Sultan', 'Devarra', 'N/A', '2024-04-14', '09050624920', '../profile_pictures/2x2pic.png', '2024-04-14 09:21:48', 'juluis', '$2y$10$JV3g0045ZNuDca/SyGjDkupw6EvyZa3l42ZVDmeoUZXXmyv7AwYMm'),
(6, 'Juje', 'Sultan', 'Bensi', 'N/A', '2002-09-10', '09432169519', '../profile_pictures/2x2pic.png', '2024-04-14 19:18:18', 'Juje', '$2y$10$YKIT4B7IdDaQuAkue600tePp5Uzc4jus/ngB9jEp71Our6gobX6.G'),
(7, 'Junnel', 'Sultan', 'Bensi', 'Jr.', '2005-12-11', '09102365898', '../profile_pictures/junnel.jpg', '2024-04-14 19:23:59', 'Junnel', '$2y$10$1GZJff1IZR6WZGHVaI0pPOr9aa6u.Yyfn/8nudOg9nwTkN4Ku4eBO'),
(8, 'Juliejen', 'Sultan', 'Bensi', 'N/A', '2008-08-05', '09123456789', '../profile_pictures/Wednesday2.PNG', '2024-04-14 19:29:22', 'Julie', '$2y$10$AI3H5wpxRe1F3t/rvtMZEeWqWZyLK9nF8da6/gllINPjQd.QoRr9W'),
(9, 'Jujechu', 'Sultan', 'Bensi', 'N/A', '2024-04-14', '03123789456', '../profile_pictures/Gojo.jpg', '2024-04-14 22:29:32', 'Jujechu', '$2y$10$pqk.gB530bgN5PqW9HiaA.clkhQ8qnioZXtDUNdb5EF7Fcx4DrKs6'),
(10, 'Zen', 'Wistaria', 'Sultan', 'N/A', '2024-04-05', '09789456153', '../profile_pictures/KenKaneki.jpg', '2024-04-14 22:57:14', 'Zen', '$2y$10$U00ZunMBtD2C7Z/RR8sGsu0yaU8E/ZGUoiSB63JTo4ltUode4Fu5m');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `useracc`
--
ALTER TABLE `useracc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `useracc`
--
ALTER TABLE `useracc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
