<?php
require_once 'config.inc.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $middlename = $_POST["middlename"];
    $suffix = $_POST["suffix"];
    $birthday = $_POST["birthday"];
    $addresss = $_POST["addresss"]; 
    $contact_number = $_POST["contactNum"];
    $email = $_POST["email"]; 
    $password = $_POST["password"];
    $image = $_FILES["image"]["name"];
    $image_temp = $_FILES["image"]["tmp_name"];
    
    $_SESSION['firstname'] = $firstname;
    $_SESSION['lastname'] = $lastname;
    $_SESSION['middlename'] = $middlename;
    $_SESSION['suffix'] = $suffix;
    $_SESSION['birthday'] = $birthday;
    $_SESSION['addresss'] = $addresss; 
    $_SESSION['contactNum'] = $contact_number;
    $_SESSION['email'] = $email;
    $_SESSION['password'] = $password;
    $_SESSION['image'] = $image;
    
    if (empty($firstname)) {
        $_SESSION['errors']['firstname'] = 'Firstname field is required.';
    }
    if (empty($lastname)) {
        $_SESSION['errors']['lastname'] = 'Lastname field is required.';
    }
    if (empty($middlename)) {
        $_SESSION['errors']['middlename'] = 'Put N/A if theres no middle name.';
    }
    if (empty($suffix)) {
        $_SESSION['errors']['suffix'] = 'Put N/A if theres no suffix.';
    }
    if (empty($birthday)) {
        $_SESSION['errors']['birthday'] = 'Birthday field is required.';
    }
    if (empty($addresss)) {
        $_SESSION['errors']['birthday'] = 'Birthday field is required.';
    }
    if (empty($contact_number)) {
        $_SESSION['errors']['contactNum'] = 'Contact number field is required.';
    }
    if (!preg_match('/^\d{11}$/', $contact_number)) {
        $_SESSION['errors']['contactNum'] = 'Contact number must be 11 digits.';
    }
    if (empty($email)) {
        $_SESSION['errors']['email'] = 'Email field is required.'; 
    }
    if (empty($password)) {
        $_SESSION['errors']['password'] = 'Password field is required.';
    }
    if (empty($image)) {
        $_SESSION['errors']['image'] = 'Profile picture is required.';
    } 
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['errors']['email'] = 'Invalid email format';
    } else {
        if ($_FILES["image"]["error"] !== UPLOAD_ERR_OK) {
            $_SESSION['errors']['image'] = 'File upload error: ' . $_FILES["image"]["error"];
        } else {
            $target_dir = "../profile_pictures/";
            $target_file = $target_dir . basename($image);
            if (move_uploaded_file($image_temp, $target_file)) {
            } else {
                $_SESSION['errors']['image'] = 'Failed to move the uploaded file.';
            }
        }
    }

    if (isset($_SESSION['errors'])) {
        header("Location: ../register.php");
        exit();
    }

    $hashedPwd = password_hash($password, PASSWORD_BCRYPT);

    try {
        require_once "dbc.inc.php";

        $query = "INSERT INTO useracc (firstname, lastname, middlename, suffix, birthday, addresss, conatctNumber, email, psswd, img) 
                  VALUES (:firstname, :lastname, :middlename, :suffix, :birthday, :addresss, :contact_number, :email, :hashedPwd, :profile_picture)";

        $stmt = $pdo->prepare($query);

        $stmt->bindParam(":firstname", $firstname);
        $stmt->bindParam(":lastname", $lastname);
        $stmt->bindParam(":middlename", $middlename);
        $stmt->bindParam(":suffix", $suffix);
        $stmt->bindParam(":birthday", $birthday);
        $stmt->bindParam(":addresss", $addresss); 
        $stmt->bindParam(":contact_number", $contact_number);
        $stmt->bindParam(":email", $email); 
        $stmt->bindParam(":hashedPwd", $hashedPwd);
        $stmt->bindParam(":profile_picture", $target_file);

        $stmt->execute();

        $pdo = null;
        $stmt = null;

        $_SESSION['success'] = 'Registration successful!';
        unset($_SESSION['firstname']); 
        unset($_SESSION['lastname']); 
        unset($_SESSION['middlename']); 
        unset($_SESSION['suffix']); 
        unset($_SESSION['birthday']);
        unset($_SESSION['addresss']); 
        unset($_SESSION['contactNum']); 
        unset($_SESSION['email']); 
        unset($_SESSION['password']); 
        unset($_SESSION['image']); 
        header("Location: ../register.php");
        die();
    } catch (PDOException $e) {
        die("Query failed: " . $e->getMessage());
    }
} else {
    header("Location: ../register.php");
}
