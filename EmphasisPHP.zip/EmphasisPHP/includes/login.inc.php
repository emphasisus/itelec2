<?php
require_once 'config.inc.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"]; 
    $password = $_POST["password"];

    $_SESSION['email'] = $email;    

    if (empty($email) || empty($password)) {
        $_SESSION['errors']['login'] = 'All fields are required.';
    } else {
        try {
            require_once "dbc.inc.php";

            $query = "SELECT * FROM useracc WHERE email = :email"; 

            $stmt = $pdo->prepare($query);

            $stmt->bindParam(":email", $email); 
            $stmt->execute();

            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {

                $hashedPwd = $result['psswd']; 

                if (password_verify($password, $hashedPwd)) {
                    $pdo = null;
                    $stmt = null;

                    header("Location: ../display.php");
                    exit();
                } else {
                    $_SESSION['errors']['login'] = 'Invalid Password';
                }
            } else {
                $_SESSION['errors']['login'] = 'Invalid Email'; 
            }
        } catch (PDOException $e) {
            die("Query failed: " . $e->getMessage());
        }
    }

} 
if (!isset($_SESSION['email'])) {
    header("Location: ../login.php");
    exit();
} else {
    header("Location: ../login.php");
}
