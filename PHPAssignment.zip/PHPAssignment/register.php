<?php require_once
 "includes/config.inc.php";
 ?>
<!DOCTYPE html> <html lang="en"> <head> <meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registration Form</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

<style> .input-error {
    border: 1px solid red; }
    .error {
        color: red; }
        </style>
        </head>
        <body>
        <div class="container my-5">
            <h1>Registration Form</h1>
        <form action="register.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="firstname">First Name:</label>
            <input type="text" class="form-control <?= isset($_SESSION['errors']['firstname']) ? 'is-invalid' : '' ?>" id="firstname" name="firstname" placeholder="Enter your first name" value="
            <?= isset($_SESSION['inputs']['firstname']) ? $_SESSION['inputs']['firstname'] : '' ?>"> <?= isset($_SESSION['errors']['firstname']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['firstname'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="lastname">Last Name:</label>
            <input type="text" class="form-control <?= isset($_SESSION['errors']['lastname']) ? 'is-invalid' : '' ?>" id="lastname" name="lastname" placeholder="Enter your last name" value="<?= isset($_SESSION['inputs']['lastname']) ? $_SESSION['inputs']['lastname'] : '' ?>">
            <?= isset($_SESSION['errors']['lastname']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['lastname'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="middlename">Middle Name:</label>
            <input type="text" class="form-control <?= isset($_SESSION['errors']['middlename']) ? 'is-invalid' : '' ?>" id="middlename" name="middlename" placeholder="Enter your middle name" value="<?= isset($_SESSION['inputs']['middlename']) ? $_SESSION['inputs']['middlename'] : '' ?>">
            <?= isset($_SESSION['errors']['middlename']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['middlename'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="suffix">Suffix:</label>
            <select class="form-control" id="suffix" name="suffix">
                <option value="">None</option>
                <option value="Jr.">Jr.</option>
                <option value="Sr.">Sr.</option>
                <option value="I">I</option>
                <option value="II">II</option>
                <option value="III">III</option>
                <option value="IV">IV</option>
            </select>
        </div>

        <div class="form-group">
            <label for="birthday">Birthday:</label>
            <input type="date" class="form-control <?= isset($_SESSION['errors']['birthday']) ? 'is-invalid' : '' ?>" id="birthday" name="birthday" value="<?= isset($_SESSION['inputs']['birthday']) ? $_SESSION['inputs']['birthday'] : '' ?>">
            <?= isset($_SESSION['errors']['birthday']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['birthday'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" class="form-control <?= isset($_SESSION['errors']['address']) ? 'is-invalid' : '' ?>" name="address" placeholder="Enter your address" value="<?= isset($_SESSION['inputs']['address']) ? $_SESSION['inputs']['address'] : '' ?>">
            <?= isset($_SESSION['errors']['address']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['address'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="contactnumber">Contact Number:</label>
            <input type="text" class="form-control <?= isset($_SESSION['errors']['contactnumber']) ? 'is-invalid' : '' ?>" id="contactnumber" name="contactnumber" placeholder="Enter your contact number" value="<?= isset($_SESSION['inputs']['contactnumber']) ? $_SESSION['inputs']['contactnumber'] : '' ?>">
            <?= isset($_SESSION['errors']['contactnumber']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['contactnumber'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="profilepicture">Profile Picture:</label>
            <input type="file" class="form-control-file <?= isset($_SESSION['errors']['profilepicture']) ? 'is-invalid' : '' ?>" id="profilepicture" name="profilepicture" accept="image/*">
            <?= isset($_SESSION['errors']['profilepicture']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['profilepicture'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="text" class="form-control <?= isset($_SESSION['errors']['email']) ? 'is-invalid' : '' ?>" id="email" name="email" placeholder="Enter your email" value="<?= isset($_SESSION['inputs']['email']) ? $_SESSION['inputs']['email'] : '' ?>">
            <?= isset($_SESSION['errors']['email']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['email'] . '</div>' : '' ?>
        </div>

        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" class="form-control <?= isset($_SESSION['errors']['password']) ? 'is-invalid' : '' ?>" id="password" name="password" placeholder="Enter your password">
            <?= isset($_SESSION['errors']['password']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['password'] . '</div>' : '' ?>
        </div>

        <button type="submit" class="btn btn-primary">Register</button>
        <div class="mt-3">
            <p>Already have an account? <a href="login.php" style="text-decoration: underline;">Login</a></p>
        </div>
    </form>

    <?php
    unset($_SESSION['errors']);
    unset($_SESSION['inputs']);
    ?>
</div>
</body> </html>