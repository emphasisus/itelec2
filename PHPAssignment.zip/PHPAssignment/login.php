<?php require_once
 "includes/config.inc.php";
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="card shadow-sm" style="width: 400px;">
            <div class="card-body">
                <h1 class="card-title text-center mb-4">Login</h1>
                <form action="includes/login.inc.php" method="get">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control <?= isset($_SESSION['errors']['username']) ? 'is-invalid' : '' ?>" name="username" id="username" placeholder="Enter Username..." value="<?= isset($_SESSION['inputs']['username']) ? $_SESSION['inputs']['username'] : '' ?>" required>
                        <?= isset($_SESSION['errors']['username']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['username'] . '</div>' : '' ?>
                    </div>
                    <div class="mb-3">
                        <label for="pwd" class="form-label">Password</label>
                        <input type="password" class="form-control <?= isset($_SESSION['errors']['pwd']) ? 'is-invalid' : '' ?>" name="pwd" id="pwd" placeholder="Enter Password..." required>
                        <?= isset($_SESSION['errors']['pwd']) ? '<div class="invalid-feedback">' . $_SESSION['errors']['pwd'] . '</div>' : '' ?>
                    </div>
                    <div class="d-flex justify-content-between mb-3">
                        <button type="submit" class="btn btn-primary">Log In</button>
                        <a href="register.php" class="btn btn-secondary">Register</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>