<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $middlename = $_POST["middlename"];
    $suffix = $_POST["suffix"];
    $birthday = $_POST["birthday"];
    $address = $_POST["address"];
    $contactnumber = $_POST["contactnumber"];
    $profilepicture = $_POST["profilepicture"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    try {
        require_once "dbc.inc.php";
        
        $query = "INSERT INTO users(firstname, lastname, middlename, suffix, birthday, address, contactnumber, profilepicture, email, password)
                VALUES (:firstname, :lastname, :middlename, :suffix, :birthday, :address, :contactnumber, :profilepicture, :email, :password)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(":firstname", $firstname);
        $stmt->bindParam(":lastname", $lastname);
        $stmt->bindParam(":middlename", $middlename);
        $stmt->bindParam(":suffix", $suffix);
        $stmt->bindParam(":birthday", $birthday);
        $stmt->bindParam(":address", $address);
        $stmt->bindParam(":contactnumber", $contactnumber);
        $stmt->bindParam(":profilepicture", $profilepicture);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":password", $hashedPassword);
        
        $stmt->execute();

        header("Location: ../login.php");
        exit();
    } catch (PDOException $e) {
        echo "Error executing query: " . $e->getMessage();
        exit();
    }
} else {
    header("Location: ../index.php");
    exit();
}