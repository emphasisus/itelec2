<?php require_once
 "includes/config.inc.php";
 ?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <style>
        .profile-picture {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <?php
        $firstname = $_SESSION['firstname'];
        $lastname = $_SESSION['lastname'];
        $middlename = $_SESSION['middlename'];
        $suffix = $_SESSION['suffix'];
        $birthday = $_SESSION['birthday'];
        $address = $_SESSION['address'];
        $contactnumber = $_SESSION['contactnumber'];
        $profilepicture = $_SESSION['profilepicture'];
        $email = $_SESSION['email'];
    ?>

    <h1>Welcome, <?php echo "$firstname $middlename $lastname $suffix"; ?>!</h1>

    <div>
        <img src="<?php echo $profilepicture; ?>" alt="Profile Picture" class="profile-picture">
    </div>

    <table>
        <tr>
            <th>Birthday:</th>
            <td><?php echo $birthday; ?></td>
        </tr>
        <tr>
            <th>Address:</th>
            <td><?php echo $address; ?></td>
        </tr>
        <tr>
            <th>Contact Number:</th>
            <td><?php echo $contactnumber; ?></td>
        </tr>
        <tr>
            <th>Email:</th>
            <td><?php echo $email; ?></td>
        </tr>
    </table>
</body>
</html>